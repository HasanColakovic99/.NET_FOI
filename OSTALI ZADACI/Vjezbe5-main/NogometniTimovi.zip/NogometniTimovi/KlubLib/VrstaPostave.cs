﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KlubLib
{
    public class VrstaPostave
    {
        public enum Postava
        {
            _4_4_2,
            _4_3_3,
            _3_5_2,
        }
    }
}
