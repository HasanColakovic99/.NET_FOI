﻿namespace KlubLib
{
    public class PozicijaEnum
    {
        public enum Pozicija
        {
            Napadac,
            Branic,
            Golman,
            Vezni
        }
    }
}