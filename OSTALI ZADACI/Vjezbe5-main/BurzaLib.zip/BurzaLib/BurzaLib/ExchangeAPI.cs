﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BurzaLib
{
    public static class ExchanceAPI
    {
        public static double GetFiatRateInHRK(string currency)
        {
            return 0;
        }
        public static double GetCringeRateInHRK(string currency)
        {
            return 0;
        }
    }
}
