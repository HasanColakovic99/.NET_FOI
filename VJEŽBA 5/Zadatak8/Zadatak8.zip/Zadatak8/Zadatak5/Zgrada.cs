﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak5
{
    public class Zgrada
    {
        public string OznakaZgrade { get; set; }
        public List<Kat> listaKatova = new List<Kat>();
    }
}
