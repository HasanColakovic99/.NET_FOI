﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak5
{
    public class Kat
    {
        public int BrojKata { get; set; }
        public List<IProstor> IProstori = new List<IProstor>();
    }
}
