﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak1
{
    public class Sezona
    {
        public int RedniBroj { get; set; }
        public List<Epizoda> listaEpizoda = new List<Epizoda>();
    }
}
