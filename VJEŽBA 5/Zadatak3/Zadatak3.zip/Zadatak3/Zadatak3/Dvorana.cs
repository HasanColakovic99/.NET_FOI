﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak3
{
    public class Dvorana
    {
        public string Oznaka { get; set; }

        public List<Sjedalo> listaSjedala = new List<Sjedalo>();
    }
}
