﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak3
{
    public class Projekcije
    {
        public DateTime Datum { get; set; }
        public Dvorana Dvorana { get; set; }
        public Film Film { get; set; }
        public bool Premijera { get; set; }
    }
}
