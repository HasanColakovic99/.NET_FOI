﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak4
{
    public class Dvorana
    {
        public string Oznaka { get; set; }
        public List<Sjedalo> listaSjedalo = new List<Sjedalo>();
    }
}
