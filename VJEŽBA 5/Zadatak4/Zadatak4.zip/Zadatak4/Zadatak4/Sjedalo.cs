﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak4
{
    public class Sjedalo
    {
        public string OznakaSjedala { get; set; }
    }
}
