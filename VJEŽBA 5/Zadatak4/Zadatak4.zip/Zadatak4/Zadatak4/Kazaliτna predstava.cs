﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak4
{
    class Kazališna_predstava : IPredstava
    {
        public string Naziv { get; set; }
    }
}
