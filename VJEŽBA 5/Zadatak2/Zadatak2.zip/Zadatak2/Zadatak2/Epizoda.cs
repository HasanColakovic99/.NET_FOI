﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak2
{
    public class Epizoda
    {
        public string Naziv { get; set; }
        public int Trajanje { get; set; }
    }
}
