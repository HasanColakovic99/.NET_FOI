﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vježba2
{
    public class Potvrda
    {
        public List<Potvrda> Potvrde = new List<Potvrda>();

    }
}
